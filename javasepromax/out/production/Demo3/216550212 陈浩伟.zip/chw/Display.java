package chw;

public interface Display {
    public void printInfo();
}
