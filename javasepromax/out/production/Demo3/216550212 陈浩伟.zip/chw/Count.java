package chw;

import java.util.ArrayList;

public class Count {
    public static int num = 0;
    public static ArrayList<StudentCourse> studentCoureArray = new ArrayList<StudentCourse>();


    public static void statistic(StudentCourse st){

        studentCoureArray.add(st);

//        System.out.println(studentCoureArray);
        boolean flog = true;
        for (StudentCourse studentCourse : studentCoureArray) {
            if (flog && st.getStudent().getId() != studentCourse.getStudent().getId()){
                num ++;
                flog = false;
            }
        }




    }
}
